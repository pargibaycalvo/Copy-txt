package arquivos;

public class Arquivos {

    public static void main(String[] args) {
        
        Seven ruta = new Seven();
        //ruta.uno();
        //ruta.dos();
        //ruta.cuatro();
        //ruta.cinco();
        //ruta.seis();
        //ruta.siete();
        //ruta.ocho();
        //ruta.nueve();
        //ruta.diez();
        //ruta.once();
    }   
}
